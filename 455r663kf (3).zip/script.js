const serviceDialog = document.getElementById("serviceDialog");
const dialogTitle = document.getElementById("dialogTitle");
const dialogContent = document.getElementById("dialogContent");

function openDialog(title, content) {
    dialogTitle.textContent = title;
    dialogContent.innerHTML = content;
    serviceDialog.showModal();
}

function closeDialog() {
    serviceDialog.close();
}

serviceDialog.addEventListener("click", (event) => {
    if (event.target === serviceDialog) closeDialog();
});

const loginButton = document.querySelector("header button");

function updateLoginButton() {
    const email = sessionStorage.getItem("loggedInEmail");
    loginButton.textContent = email ? "Chiqish" : "Kirish";
    loginButton.setAttribute("aria-label", email ? `${email} — chiqish` : "Kirish");
}

updateLoginButton();

function login() {
    if (sessionStorage.getItem("loggedInEmail")) {
        sessionStorage.removeItem("loggedInEmail");
        updateLoginButton();
        return;
    }

    openDialog("Kirish", `
        <form id="loginForm" class="dialog-form">
            <label for="loginEmail">Elektron pochta</label>
            <input id="loginEmail" type="email" placeholder="name@example.com" required>
            <label for="loginPassword">Parol</label>
            <input id="loginPassword" type="password" minlength="4" placeholder="Parolingiz" required>
            <button type="submit">Kirish</button>
            <p id="loginMessage" class="result" aria-live="polite"></p>
            <small>Demo rejim: bu yerda akkaunt tekshiruvi yo‘q, ma’lumotlar faqat shu brauzer seansida saqlanadi.</small>
        </form>
    `);

    document.getElementById("loginForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const email = document.getElementById("loginEmail").value.trim();
        sessionStorage.setItem("loggedInEmail", email);
        updateLoginButton();
        document.getElementById("loginMessage").textContent = `Xush kelibsiz, ${email}! Demo rejimda tizimga kirdingiz.`;
    });
}

function start() {
    document.getElementById("xizmatlar").scrollIntoView({ behavior: "smooth" });
}

function test() {
    openDialog("Bilimingizni sinang", `
        <form id="quizForm" class="dialog-form">
            <fieldset>
                <legend>HTML sahifaning tuzilishini belgilaydigan tilmi?</legend>
                <label class="option"><input type="radio" name="answer" value="yes" required> Ha</label>
                <label class="option"><input type="radio" name="answer" value="no"> Yo‘q</label>
            </fieldset>
            <button type="submit">Javobni tekshirish</button>
            <p id="quizResult" class="result" aria-live="polite"></p>
        </form>
    `);

    document.getElementById("quizForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const answer = new FormData(event.currentTarget).get("answer");
        document.getElementById("quizResult").textContent = answer === "yes"
            ? "To‘g‘ri javob!"
            : "Noto‘g‘ri. HTML sahifa tuzilishini belgilaydi.";
    });
}

function calculator() {
    openDialog("Kalkulyator", `
        <form id="calculatorForm" class="dialog-form">
            <label for="firstNumber">Birinchi son</label>
            <input id="firstNumber" type="number" step="any" required>
            <label for="operation">Amal</label>
            <select id="operation">
                <option value="add">Qo‘shish (+)</option>
                <option value="subtract">Ayirish (−)</option>
                <option value="multiply">Ko‘paytirish (×)</option>
                <option value="divide">Bo‘lish (÷)</option>
            </select>
            <label for="secondNumber">Ikkinchi son</label>
            <input id="secondNumber" type="number" step="any" required>
            <button type="submit">Hisoblash</button>
            <p id="calculationResult" class="result" aria-live="polite"></p>
        </form>
    `);

    document.getElementById("calculatorForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const first = Number(document.getElementById("firstNumber").value);
        const second = Number(document.getElementById("secondNumber").value);
        const operation = document.getElementById("operation").value;
        let result;

        if (operation === "add") result = first + second;
        if (operation === "subtract") result = first - second;
        if (operation === "multiply") result = first * second;
        if (operation === "divide") {
            if (second === 0) {
                document.getElementById("calculationResult").textContent = "Nolga bo‘lish mumkin emas.";
                return;
            }
            result = first / second;
        }

        document.getElementById("calculationResult").textContent = `Natija: ${result}`;
    });
}

function info() {
    openDialog("Ma’lumotlar", `
        <div class="dialog-form">
            <p><strong>dasturchi.uz</strong> — web dasturlash va foydali onlayn xizmatlar uchun shaxsiy sayt.</p>
            <p>Saytda test ishlashingiz, oddiy amallarni kalkulyatorda hisoblashingiz va aloqa ma’lumotlarini ko‘rishingiz mumkin.</p>
            <p>Email: <a href="mailto:muxiddinovanvar05@gmail.com">muxiddinovanvar05@gmail.com</a></p>
            <p>Telefon: <a href="tel:+998912442005">+998912442005</a></p>
        </div>
    `);
}
